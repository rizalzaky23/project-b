import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/dark_theme.dart';
import '../../../../shared/widgets/app_loading.dart';
import '../../../../shared/widgets/empty_state.dart';
import '../../../../shared/widgets/confirm_dialog.dart';
import '../bloc/kendaraan_bloc.dart';
import '../widgets/kendaraan_card.dart';

class KendaraanListScreen extends StatefulWidget {
  const KendaraanListScreen({super.key});

  @override
  State<KendaraanListScreen> createState() => _KendaraanListScreenState();
}

class _KendaraanListScreenState extends State<KendaraanListScreen> {
  final _searchController = TextEditingController();
  final _scrollController = ScrollController();

  String? _selectedKepemilikan; // null = semua

  static const List<String> _ptOptions = ['PT1', 'PT2', 'PT3'];

  @override
  void initState() {
    super.initState();
    context.read<KendaraanBloc>().add(KendaraanLoadRequested());
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 200) {
      context.read<KendaraanBloc>().add(KendaraanLoadMoreRequested());
    }
  }

  void _onSearch(String value) {
    setState(() {});
    context.read<KendaraanBloc>().add(KendaraanLoadRequested(
      search: value,
      kepemilikan: _selectedKepemilikan,
    ));
  }

  void _onFilterKepemilikan(String? pt) {
    setState(() => _selectedKepemilikan = pt);
    context.read<KendaraanBloc>().add(KendaraanLoadRequested(
      search: _searchController.text.isEmpty ? null : _searchController.text,
      kepemilikan: pt,
    ));
  }

  /// Navigasi ke form create, tunggu hasilnya, lalu refresh otomatis
  Future<void> _goCreate() async {
    await context.push('/kendaraan/create');
    if (mounted) {
      context.read<KendaraanBloc>().add(KendaraanLoadRequested(
        kepemilikan: _selectedKepemilikan,
      ));
    }
  }

  Color _ptColor(String pt) {
    switch (pt) {
      case 'PT1': return const Color(0xFF6C63FF);
      case 'PT2': return const Color(0xFF00C6AE);
      case 'PT3': return const Color(0xFFFF8C69);
      default: return AppTheme.primary;
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isTablet = size.width >= 600 && size.width < 1024;
    final isDesktop = size.width >= 1024;
    final hPad = isDesktop ? 48.0 : isTablet ? 24.0 : 16.0;
    final int crossAxisCount = isDesktop ? 4 : isTablet ? 3 : 2;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) context.go('/dashboard');
      },
      child: Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    colors: [AppTheme.primary, Color(0xFF8B84FF)]),
                borderRadius: BorderRadius.circular(9),
              ),
              child: const Icon(Icons.directions_car_rounded,
                  color: Colors.white, size: 16),
            ),
            const SizedBox(width: 10),
            const Text('Kendaraan'),
          ],
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () =>
              context.canPop() ? context.pop() : context.go('/dashboard'),
        ),
      ),
      body: BlocListener<KendaraanBloc, KendaraanState>(
        listener: (context, state) {
          if (state is KendaraanActionSuccess) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text(state.message),
                backgroundColor: AppTheme.success));
            // Refresh otomatis setelah aksi berhasil
            context.read<KendaraanBloc>().add(KendaraanLoadRequested(
              kepemilikan: _selectedKepemilikan,
            ));
          } else if (state is KendaraanActionError) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text(state.failure.message),
                backgroundColor: AppTheme.error));
          }
        },
        child: Column(
          children: [
            // ── Search bar ─────────────────────────────────────────
            Container(
              padding: EdgeInsets.fromLTRB(hPad, 12, hPad, 0),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                border: Border(
                    bottom:
                        BorderSide(color: Theme.of(context).dividerColor)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    controller: _searchController,
                    onChanged: _onSearch,
                    decoration: InputDecoration(
                      hintText: 'Cari kendaraan...',
                      prefixIcon: const Icon(Icons.search,
                          color: AppTheme.primary, size: 20),
                      suffixIcon: _searchController.text.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.clear, size: 18),
                              onPressed: () {
                                _searchController.clear();
                                _onSearch('');
                              },
                            )
                          : null,
                    ),
                  ),
                  const SizedBox(height: 10),
                  // ── Filter chips kepemilikan ──────────────────────
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        // Chip "Semua"
                        Padding(
                          padding: const EdgeInsets.only(right: 8, bottom: 10),
                          child: FilterChip(
                            label: const Text('Semua'),
                            selected: _selectedKepemilikan == null,
                            onSelected: (_) => _onFilterKepemilikan(null),
                            selectedColor: AppTheme.primary.withOpacity(0.2),
                            checkmarkColor: AppTheme.primary,
                            labelStyle: TextStyle(
                              color: _selectedKepemilikan == null
                                  ? AppTheme.primary
                                  : AppTheme.textSecondary,
                              fontWeight: _selectedKepemilikan == null
                                  ? FontWeight.w600
                                  : FontWeight.normal,
                            ),
                            side: BorderSide(
                              color: _selectedKepemilikan == null
                                  ? AppTheme.primary
                                  : Colors.transparent,
                            ),
                          ),
                        ),
                        // Chips PT1, PT2, PT3
                        ..._ptOptions.map((pt) {
                          final isSelected = _selectedKepemilikan == pt;
                          final ptColor = _ptColor(pt);
                          return Padding(
                            padding: const EdgeInsets.only(right: 8, bottom: 10),
                            child: FilterChip(
                              label: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Container(
                                    width: 8,
                                    height: 8,
                                    decoration: BoxDecoration(
                                      color: ptColor,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Text(pt),
                                ],
                              ),
                              selected: isSelected,
                              onSelected: (_) => _onFilterKepemilikan(isSelected ? null : pt),
                              selectedColor: ptColor.withOpacity(0.2),
                              checkmarkColor: ptColor,
                              labelStyle: TextStyle(
                                color: isSelected ? ptColor : AppTheme.textSecondary,
                                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                              ),
                              side: BorderSide(
                                color: isSelected ? ptColor : Colors.transparent,
                              ),
                            ),
                          );
                        }),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: BlocBuilder<KendaraanBloc, KendaraanState>(
                builder: (context, state) {
                  if (state is KendaraanLoading) return const AppLoading();
                  if (state is KendaraanError) {
                    return EmptyState(
                      message: state.failure.message,
                      icon: Icons.error_outline,
                      onRetry: () => context
                          .read<KendaraanBloc>()
                          .add(KendaraanLoadRequested(
                            kepemilikan: _selectedKepemilikan,
                          )),
                    );
                  }
                  if (state is KendaraanLoaded) {
                    if (state.items.isEmpty) {
                      return EmptyState(
                        message: _selectedKepemilikan != null
                            ? 'Tidak ada kendaraan untuk $_selectedKepemilikan'
                            : 'Belum ada data kendaraan',
                        icon: Icons.directions_car_outlined,
                      );
                    }
                    return Column(
                      children: [
                        Padding(
                          padding: EdgeInsets.fromLTRB(hPad, 12, hPad, 4),
                          child: Row(
                            children: [
                              Container(
                                width: 4, height: 16,
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [AppTheme.primary, AppTheme.secondary],
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                  ),
                                  borderRadius: BorderRadius.circular(2),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                '${state.meta.total} kendaraan'
                                '${_selectedKepemilikan != null ? ' · $_selectedKepemilikan' : ''}',
                                style: const TextStyle(
                                    color: AppTheme.textSecondary,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w500),
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: GridView.builder(
                            controller: _scrollController,
                            padding: EdgeInsets.fromLTRB(hPad, 8, hPad, 100),
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: crossAxisCount,
                              childAspectRatio: isDesktop
                                  ? 0.78
                                  : isTablet
                                      ? 0.76
                                      : 0.74,
                              crossAxisSpacing: 12,
                              mainAxisSpacing: 12,
                            ),
                            itemCount: state.items.length,
                            itemBuilder: (context, index) {
                              final item = state.items[index];
                              return KendaraanCard(
                                kendaraan: item,
                                // Pass entity via extra → tidak perlu load ulang
                                onTap: () => context.push(
                                    '/kendaraan/${item.id}',
                                    extra: item),
                                onEdit: () async {
                                  await context.push(
                                      '/kendaraan/${item.id}/edit',
                                      extra: item);
                                  // Refresh setelah kembali dari edit
                                  if (context.mounted) {
                                    context.read<KendaraanBloc>().add(
                                        KendaraanLoadRequested(
                                          kepemilikan: _selectedKepemilikan,
                                        ));
                                  }
                                },
                                onDelete: () async {
                                  final confirm = await showConfirmDialog(
                                    context,
                                    title: 'Hapus Kendaraan',
                                    message:
                                        'Yakin ingin menghapus ${item.merk} ${item.tipe}?',
                                  );
                                  if (confirm && context.mounted) {
                                    context.read<KendaraanBloc>().add(
                                        KendaraanDeleteRequested(item.id));
                                  }
                                },
                              );
                            },
                          ),
                        ),
                        if (state.isLoadingMore)
                          const Padding(
                            padding: EdgeInsets.all(16),
                            child: AppLoading(),
                          ),
                      ],
                    );
                  }
                  return const SizedBox();
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _goCreate,
        icon: const Icon(Icons.add),
        label: const Text('Tambah'),
        backgroundColor: AppTheme.primary,
        foregroundColor: Colors.white,
      ),
    ),
    );
  }
}
